import com.adobe.cq.sightly.WCMUsePojo;
import com.brightedge.ixf.IXFSDKClient;
import com.brightedge.ixf.util.*;


public class BrightEdgeUtil extends WCMUsePojo {

    private IXFConfiguration ixfConfig;

    private String headOpen;
    private String bodyString;
    private String pagePath;
    private String hostname;
    private String country;

    @Override
    public void activate() throws Exception {
        String currenturl = this.getRequest().getRequestURL().toString();
		hostname="www.xxxx.com";
       

        this.pagePath=get("pagePath",String.class);
        this.country=get("country",String.class);
       

        IXFConfiguration ixfConfig = new IXFSDKConfiguration();
        ixfConfig.setProperty(IXFConfiguration.CAPSULE_MODE, IXFConfiguration.REMOTE_PROD_CAPSULE_MODE);
        ixfConfig.setProperty(IXFConfiguration.ACCOUNT_ID, "f00000000121591");
		ixfConfig.SetProperty(IXFConfiguration.API_ENDPOINT, "https://ixfd1-api.bc0a.com/");


		//BE IXF: Update CHARSET if needed
        ixfConfig.setProperty(IXFConfiguration.CHARSET, "UTF-8");
		
		//BE IXF: By default, all URL parameters are ignored. If you have URL parameters that add value to page content.  Add them to this config value, separated by the pipe character (|).
        ixfConfig.setProperty(IXFConfiguration.WHITELIST_PARAMETER_LIST, "ixf");

		//Log Level options:LOG_LEVEL_ALL,LOG_LEVEL_INFO,LOG_LEVEL_WARN,LOG_LEVEL_ERROR,LOG_LEVEL_DEBUG
        ixfConfig.setProperty(IXFConfiguration.LOG_LEVEL, IXFConfiguration.LOG_LEVEL_ERROR);

        ixfConfig.setProperty(IXFConfiguration.PAGE_ALIAS_URL,"https://"+hostname+"/"+this.pagePath);
		
        //Optional parameters
        //ixfConfig.setProperty(IXFConfiguration.PROXY_HOST, hostname);
        //ixfConfig.setProperty(IXFConfiguration.PROXY_PORT, "1234");
        //ixfConfig.setProperty(IXFConfiguration.PROXY_PROTOCOL, "https");

		
        IXFSDKParameters parameters = new IXFSDKParameters(this.getRequest());
        IXFSDKClient client = new IXFSDKClient(ixfConfig, this.getResponse(), parameters);
		
        headOpen=client.getHeadOpen();
        bodyString=client.getBodyString("body_1");
		closeString=client.close();
    }

    public IXFConfiguration getIxfConfig() {
        return ixfConfig;
    }

    public String getHeadOpen(){
        return headOpen;
    }
    public String getBodyString(){
       return bodyString;
    }
    public String getCloseString(){
       return closeString;
    }

}
